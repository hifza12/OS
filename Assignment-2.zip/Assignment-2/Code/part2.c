#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

int main()
{
int mat_size =1024;            //For matrics size

 printf("\n ***** MatrixSize[%dx%d] ***** \n",mat_size,mat_size);

pid_t pid;

int *arr[mat_size],*arr1[mat_size],*arr2[mat_size]; //pointers for array

for(int i=0;i<mat_size;i++) //conversion of array into matrics
{
arr[i]=(int*)malloc(mat_size*sizeof(int));  //mat A
arr1[i]=(int*)malloc(mat_size*sizeof(int)); //mat B
arr2[i]=(int*)malloc(mat_size*sizeof(int)); //result
}


for(int i=0; i<mat_size; i++) //for random number
{
for(int j=0; j<mat_size; j++)
{
arr[i][j]=arr1[i][j]=rand()%10;
}

}

float totaltime; //cpu time
//child process for addition
pid=fork();
if(pid==0)
{
clock_t startA, endA;   //clock time

startA = clock(); //Process Starting time
for(int i=0; i<mat_size; i++)
{
for(int j=0; j<mat_size; j++)
{
  arr2[i][j]=arr[i][j]+arr1[i][j]; //result in arr2
}

}
endA = clock();

totaltime = ((float) (endA - startA)/CLOCKS_PER_SEC); //time in sec
        printf("Addition time of Child Process is %f sec \n",totaltime);//calculated time
printf("\n");
return 0;
}

//child process for substraction
pid=0;
pid=fork();
if(pid==0)
{
clock_t startS, endS; //clock time

startS = clock();     //Process Starting time
for(int i=0; i<mat_size; i++)
{
for(int j=0; j<mat_size; j++)
{
 arr2[i][j]=arr[i][j]-arr1[i][j]; //result in arr2
}

}
endS = clock();

totaltime= ((float) (endS - startS)/CLOCKS_PER_SEC); //time in sec
printf("Subtraction time of Child Process is %f sec \n",totaltime); //calculated time
        printf("\n");
return 0;
}



//child process for multiplication
pid=0;
pid=fork();

if(pid==0)
{
clock_t startM, endM; //clock time

startM = clock(); //Process Starting time
for(int i=0; i<mat_size; i++)
{
for(int j=0; j<mat_size; j++)
{
arr2[i][j]=arr[i][j]*arr1[i][j]; //result in arr2
}
}

endM = clock();

totaltime= ((float) (endM - startM)/CLOCKS_PER_SEC); //time in sec
printf("Multiplication time of Child Process is %f sec \n",totaltime); //calculated time
printf("\n");
return 0;
}



wait(0);//add wait
wait(0);//sub wait
wait(0);//mult wait
exit(0);

}


	
	
	

