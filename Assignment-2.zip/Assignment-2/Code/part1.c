#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <time.h>

int main()
{
int mat_size =1024;            //For matrics size
clock_t start, end;   //clock time
float totaltime; //cpu time
int *arr[mat_size],*arr1[mat_size],*arr2[mat_size]; //pointers for array

printf("\n  ***** MatrixSize[%dx%d] *****\n",mat_size,mat_size);

for(int i=0;i<mat_size;i++) //conversion of array into matrics
{
arr[i]=(int*)malloc(mat_size*sizeof(int));  //matrix A
arr1[i]=(int*)malloc(mat_size*sizeof(int)); //matrix B
arr2[i]=(int*)malloc(mat_size*sizeof(int)); //result
}

for(int i=0; i<mat_size; i++) //genertaing random number
{
for(int j=0; j<mat_size; j++)
{
arr[i][j]=arr1[i][j]=rand()%10;
}

}

start = clock(); // Starting time of processes
for(int i=0; i<mat_size; i++)
{
for(int j=0; j<mat_size; j++)
{
  arr2[i][j]=arr[i][j]+arr1[i][j]; //result in arr2
}

}
end = clock();
totaltime = ((float) (end - start)/CLOCKS_PER_SEC); //time in sec
    printf(" Here Addition time is %f sec \n",totaltime);//calculated time

start=end=totaltime=0; //reset the value of variables

//for Subtraction
start = clock();  //Process Starting time
for(int i=0; i<mat_size; i++)
{
for(int j=0; j<mat_size; j++)
{
 arr2[i][j]=arr[i][j]-arr1[i][j]; //result in arr2
}

}
end = clock();

totaltime= ((float) (end - start)/CLOCKS_PER_SEC); //time in sec

printf("Substruction time is %f sec \n",totaltime); //calculated time

start=end=totaltime=0; //reset the value of variables


        //for Multiplication
start = clock(); //Process Starting time
for(int i=0; i<mat_size; i++)
{
for(int j=0; j<mat_size; j++)
{
arr2[i][j]=arr[i][j]*arr1[i][j]; //result in arr2
}
}

end = clock();

totaltime= ((float) (end - start)/CLOCKS_PER_SEC); //time in sec
printf("Multiplication time is %f sec \n",totaltime); //calculated time

exit(0);
}





	
	
	

